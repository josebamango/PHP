create view vistamoviles as
select `d`.`id_dispositivo` AS `id_dispositivo`,
       `d`.`modelo`         AS `modelo`,
       `d`.`precio`         AS `precio`,
       `d`.`gama`           AS `gama`,
       `d`.`anio`           AS `anio`,
       `d`.`ram`            AS `ram`,
       `d`.`almacenamiento` AS `almacenamiento`,
       `d`.`procesador`     AS `procesador`,
       `d`.`bateria`        AS `bateria`,
       `d`.`pulgadas`       AS `pulgadas`,
       `m`.`id_movil`       AS `id_movil`,
       `m`.`camara`         AS `camara`,
       `m`.`notch`          AS `notch`
from (`tienda_moviles`.`dispositivos` `d`
         join `tienda_moviles`.`moviles` `m` on (`d`.`id_dispositivo` = `m`.`id_movil`));

