<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
</head>
<body>
    <?php
        $x = -1;
        $y = 9;
        echo "La suma de x=-1 e y=9 es:";
        echo $x+$y;
    ?>
</body>
</html>