<?php
$x = -1;
$y = 9;
$suma = $x + $y;
print ("El valor de x es <i>$x<i>");
print ("<br/>");
print("El valor de y es <i>$y</i><br/>");
print("La suma es <b><i>$suma</i></b><br/>");
?>