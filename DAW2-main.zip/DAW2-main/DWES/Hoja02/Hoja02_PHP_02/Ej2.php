<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 2</title>
</head>
<body>
    <?php
        print ("Segundo ejercicio: visualización del contenido
        de las variables.<br>");
        //Nombre a mostrar dentro del mensaje
        $nombre = "Daniel";
        //Edad que se muestra dentro del mensaje
        $edad = 27;
        print ("Mi nombre es $nombre y mi edad es $edad.");
    ?>
</body>
</html>