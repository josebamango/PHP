<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=ç, initial-scale=1.0">
    <title>Ejercicio 6</title>
</head>
<body>
    <?php
        $n1 = 3;
        $n2 = 7;
        $n3 = 12;
        $media = ($n1 + $n2 + $n3)/3;
        print ("La media de $n1, $n2 y $n3 es $media.")
    ?>
</body>
</html>