<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 3</title>
</head>
<body>
    <?php
        $operador1 = 13;
        $operador2 = 4;
        $resultado = $operador1 - $operador2;
        print ("El resultado de la resta es: $resultado<br>");
        $resultado = $operador1 + $operador2;
        print ("El resultado de la suma es: $resultado<br>");
        $resultado = $operador1 * $operador2;
        print ("El resultado de la multiplicación es: $resultado
        <br>");
        $resultado = $operador1 / $operador2;
        print ("El resultado de la división es: $resultado<br>");
        $resultado = $operador1 % $operador2;
        print ("El resto de $operador1 entre $operador2 es: $resultado");
        

    ?>
</body>
</html>