<?php
    function imprimir($string){
        echo $string;
    }
