<?php
function suma($n, $j)
{
    return $n + $j;
}
