<?php
if (isset($_POST["nombre"])) {
    print_r($_POST);
}
?>