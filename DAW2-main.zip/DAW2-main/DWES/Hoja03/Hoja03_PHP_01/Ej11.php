<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ejercicio 11</title>
</head>
<body>
    <?php 
        
        for ($i=10; $i > 0; $i--) { 
            for ($j=$i; $j > 0; $j--) { 
                print $j." ";

            }
            print "<br>";
        }
    ?>
</body>
</html>