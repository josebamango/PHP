let valor = parseInt(prompt("Introduzca un valor"));
if (valor < 0) {
    document.write("El valor es negativo");
} else if (valor > 0) {
    document.write("El valor es positivo");
} else {
    document.write("El valor es cero");
}