let input = parseInt(prompt("¿Cuanto vale 15 + 15?"));

let respuesta = input == 30 ? "Correcto" : "Incorrecto";

alert(respuesta);