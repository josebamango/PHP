let input = parseInt(prompt("Introduzca un numero"));

if (input % 2 == 0) {
    alert(`${input} es un numero par`);
} else {
    alert(`${input} es un numero impar`);
}