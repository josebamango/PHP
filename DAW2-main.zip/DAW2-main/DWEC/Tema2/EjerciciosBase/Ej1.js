let entero = 1357;
let decimal = 135.7;
let cientifico = 135e7;
let octal = 01357;
let hexadecimal = 0x1357;

alert("Numero " + typeof(entero) + " " + entero);
alert("Numero decimal " + typeof(decimal) + " "  + decimal);
alert("Numero cientifico " + typeof(cientifico) + " "  + cientifico);
alert("Numero octal " + typeof(octal) + " "  + octal);
alert("Numero hexadecimal " + typeof(hexadecimal) + " "  + hexadecimal);