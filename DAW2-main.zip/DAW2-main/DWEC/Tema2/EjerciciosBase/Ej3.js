let operacion1 = (10 == 10);
let operacion2 = (10 === 10);
let operacion3 = (10 === 10.0);
let operacion4 = ("Laura" == "laura");
let operacion5 = ("Laura" > "laura");
let operacion6 = ("Laura" < "laura");
let operacion7 = ("123" == 123);
let operacion8 = ("123" === 123);
let operacion9 = (parseInt("123") === 123);
alert("La operación 10==10 es " + operacion1 + 
"\nLa operación 10===10 es " + operacion2 +
"\nLa operación 10===10.0 es " + operacion3 +
"\nLa operación 'Laura' == 'laura' es " + operacion4 + 
"\nLa operación 'Laura' > 'laura' es " + operacion5 + 
"\nLa operación 'Laura' < 'laura' es " + operacion6 +
"\nLa operación '123' == 123 es " + operacion7 + 
"\nLa operación '123' === 123 es " + operacion8 + 
"\nLa operación parseInt('123') === 123 es " + operacion9)