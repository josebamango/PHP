let nombre = prompt("Introduzca su nombre y apellidos");
alert("Su nombre es: " + nombre);