let resultado = 11;
for (let i = 1; i <= 25; i++) {
    document.write(`${resultado * i} - `);

}