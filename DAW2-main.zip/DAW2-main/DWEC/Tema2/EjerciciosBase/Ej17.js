let suma = 0;
for (let i = 0; i < 5; i++) {
    suma += parseInt(prompt("Introduzca un numero para sumar"));
}
alert(`La suma total es ${suma}`);