alert("Hola que tal");
alert(`Hola
que tal`);
alert(`Holaque
tal`);
alert(`Hola
que
t
al`);