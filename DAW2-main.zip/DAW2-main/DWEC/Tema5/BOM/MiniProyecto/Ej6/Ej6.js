addEventListener("load", inicio, false);

function inicio() {
    let ancho = prompt("Introduzca el ancho de la pagina");
    let alto = prompt("Introduzca el alto de la pagina");


}