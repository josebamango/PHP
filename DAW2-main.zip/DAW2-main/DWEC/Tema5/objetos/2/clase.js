function Calcular() {
    
}