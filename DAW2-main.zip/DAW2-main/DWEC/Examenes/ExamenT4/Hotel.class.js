function Hotel() {
    this.nombre = "Hotel Las Maravillas del Miguel Herrero";
    this.logo = "logo.png";
    this.direccion = "Julio Hauzeur 59";
    this.telefono = "942882498";
    this.categoria = "*****";
}
